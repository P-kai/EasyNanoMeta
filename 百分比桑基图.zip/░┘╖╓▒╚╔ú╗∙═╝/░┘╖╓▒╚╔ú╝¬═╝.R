library(readxl)
library(ggplot2)
library(tidyr)
library(optparse)
library(ggalluvial)
library(alluvial)

Random_bar_chart <- function(x){
  temp <- gather(x, E1, E2, -taxi)
  temp$taxi <- reorder(temp$taxi, -temp$E2)
  colors <- c("#FF0000", "#00FF00", "#0000FF","#CD69C9", "#D2691E","#925bea",
              "#6495ED","#0dbc21", "#a1ce4c","#167275", "#391c82","#2baeb5",
              "#6373ed", "#5b910f","#99db27", "#e07233", "#ff523f","#f9a270",
              "#7b34c1" ,"#0cf29a" ,"#d80fc1","#22547f", "#db5e92","#07a301")
  ggplot(temp, aes(x=E1, y=E2,alluvium = taxi)) +
    geom_alluvium(aes(fill= taxi, colour= taxi),
                  alpha= 0.2, width = 0.3) +
    geom_bar(stat="identity",aes(fill=taxi), width = 0.4,alpha= 0.7) +
    theme_classic() +
    theme(axis.text.x = element_text(angle=60, vjust = 1, hjust =1),
          panel.grid.major = element_line(colour = NA)) +
    labs(colour="Taxonomy",fill="Taxonomy", x="",y="Relative abundance (%)", base_size = 20)+
    theme(axis.title.x = element_text(size = 20),
          axis.title.y = element_text(size = 20)) +
    theme(axis.text.x = element_text( size = 20, colour = "black")) +
    theme(axis.text.y = element_text(size = 20, colour = "black")) +
    theme(legend.text = element_text(size = 20),legend.title =element_text(size = 18))+
    scale_fill_manual(values = sample(colors)) +
    scale_y_continuous(expand = c(0,0))
}

taxi = read.table("C:/Users/86183/Desktop/��ʱ�ļ�/phylum.txt", sep="\t",quote="",
                  header = T)
p = Random_bar_chart(taxi)
ggsave("C:/Users/86183/Desktop/��ʱ�ļ�/phylum.pdf", p, width = 10, height = 6)
p
