library(dplyr)
library(vegan)
library(linkET)
library(cols4all)
library(patchwork)
library(ggtext)
library(ggplot2)

aa <- read.table("C:/Users/86183/Desktop/plot/ARGs.txt", sep="\t",quote="",
                row.names = 1,   header = T, check.names=FALSE)
bb <- read.table("C:/Users/86183/Desktop/plot/genus.txt", sep="\t",quote="",
                 row.names = 1,   header = T, check.names=FALSE)

correlate(bb, aa, method = "spearman") %>% 
  qcorrplot() +
  geom_square() +
  geom_mark(sep = '\n',size = 3, sig_level = c(0.05, 0.01, 0.001),
            sig_thres = 0.05, color = 'white') + #���������Ժ������ֵ
  scale_fill_gradientn(colours = RColorBrewer::brewer.pal(11, "RdBu"))


mantel <- mantel_test(bb, aa,
                      spec_select = list(Mycobacterium=1,Escherichia=2,Acinetobacter=3,
                                         Pseudomonas=4,Streptomyces=5,Acidovorax=6,
                                         Bacteroides=7,Prevotella=8,Thauera=9,
                                         Flavobacterium=10,Aeromonas=11,
                                         Aliarcobacter=12,Klebsiella=13,
                                         Phocaeicola=14,
                                         Moraxella=15))%>% 
  mutate(rd = cut(r, breaks = c(-Inf,  0.5, Inf),
                  labels = c("< 0.5", ">= 0.5")),
         pd = cut(p, breaks = c(-Inf, 0.01, 0.05, Inf),
                  labels = c("< 0.01", "0.01 - 0.05", ">= 0.05")))

qcorrplot(correlate(aa), type = "lower", diag = FALSE) +
  geom_square() +geom_mark(sep = '\n',size = 1.2, sig_level = c(0.05, 0.01, 0.001),
                           sig_thres = 0.05,color="white") +
  geom_couple(aes(colour = pd, size = rd), 
              data = mantel, 
              curvature = nice_curvature()) +
  scale_fill_gradientn(colours = RColorBrewer::brewer.pal(11, "RdBu")) +
  scale_size_manual(values = c(0.5, 1, 2)) +
  scale_colour_manual(values = color_pal(3)) +
  guides(size = guide_legend(title = "Mantel's r",
                             override.aes = list(color = "black"), 
                             order = 2),
         colour = guide_legend(title = "Mantel's p", 
                               override.aes = list(size = 3), 
                               order = 1),
         fill = guide_colorbar(title = "Pearson's r", order = 3))
